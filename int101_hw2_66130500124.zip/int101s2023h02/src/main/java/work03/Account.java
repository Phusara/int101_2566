package work03;

import java.util.Objects;
import work01.Utilitor;
import work02.Person;

public class Account{
    private static long nextNo = 100_000_000;
    private final long no;
    private Person owner;
    private double balance;
    
    public Account(Person owner){
        if (owner == null)
            throw new NullPointerException();
        this.balance = 0.0;
        
        long result = Utilitor.computeIsbn10(nextNo);
        while(result == 10){
            nextNo++;
        }
        this.no = 10 * nextNo + result;
        nextNo++;
    }

    public long getNo() {
        return no;
    }
    public Person getOwner() {
        return owner;
    }
    public double getBalance() {
        return balance;
    }
    
    public double deposit(double amount){
        double checkdeposit = Utilitor.testPositive(amount);
        balance += amount;
        return balance;
    }
    
    public double withdraw(double amount){
        double checkamount = Utilitor.testPositive(amount);
        balance -= amount;
        double checkbalance = Utilitor.testPositive(balance);
        return balance;
    }
    public void tranfer(double amount, Account account){
        if(account == null || balance - amount < 0)
            throw new IllegalArgumentException();
        account.deposit(amount);
        withdraw(amount);
    }

    @Override
    public String toString() {
        return "Account{" + "no=" + no + ", balance=" + balance + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Account other = (Account) obj;
        if (this.no != other.no) {
            return false;
        }
        if (Double.doubleToLongBits(this.balance) != Double.doubleToLongBits(other.balance)) {
            return false;
        }
        return Objects.equals(this.owner, other.owner);
    }
    
    
} 