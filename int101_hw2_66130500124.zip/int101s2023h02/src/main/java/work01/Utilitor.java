
package work01;

public class Utilitor {
    
    public static String testString(String value){
        if( value == null )
            throw new NullPointerException("value can not be null");
        if ( value.isBlank() )
            throw new IllegalArgumentException("value can not blank");
        return value;
    }
    
    public static double testPositive(double value){
        if( value < 0 )
            throw new  IllegalArgumentException("value must be positive");
        else{
            return value;
        }
    }
    
    public static long computeIsbn10(long isbn10){
        int sum = 0;
        for(int i =2; isbn10 != 0; i++){
            sum += (isbn10%10)*i;
            isbn10 /= 10;
        } 
        long result = sum%11;
        return result;
    }    
    
}
